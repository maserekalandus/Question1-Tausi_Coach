/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.arrivaltimecalculator;

/**
 *
 * @author HP
 */
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class ArrivalTimeCalculator {

    public static void main(String[] args) {
        int totalDistance = 10000; 
        double speedMetersPerSecond = 225.5;
        
        double distanceMeters = totalDistance * 1000;
        double travelTimeSeconds = distanceMeters / speedMetersPerSecond;
        
        int hours = (int) (travelTimeSeconds / 3600);
        int minutes = (int) ((travelTimeSeconds % 3600) / 60);
        int seconds = (int) (travelTimeSeconds % 60);

        LocalTime departureTime = LocalTime.of(9, 0);
        LocalTime arrivalTime = departureTime.plusHours(hours).plusMinutes(minutes).plusSeconds(seconds);

      
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss");
        String formattedArrivalTime = arrivalTime.format(formatter);

        System.out.printf("Departure Time: 09:00:00%n");
        System.out.printf("Estimated Arrival Time: %s%n", formattedArrivalTime);
    }
}
