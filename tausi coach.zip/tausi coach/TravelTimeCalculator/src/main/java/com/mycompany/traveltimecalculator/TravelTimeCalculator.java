/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.traveltimecalculator;

/**
 *
 * @author HP
 */
public class TravelTimeCalculator {

    public static void main(String[] args) {
        int totalDistance = 10000;
        int speed = 250;
        int stopIntervalPassenger = 150;
        int stopIntervalRefueling = 200;
        int stopTimeMinutes = 5;

        int passengerStops = totalDistance / stopIntervalPassenger;
        int refuelingStops = totalDistance / stopIntervalRefueling;

        if (totalDistance % stopIntervalPassenger == 0) {
            passengerStops--;
        }
        if (totalDistance % stopIntervalRefueling == 0) {
            refuelingStops--;
        }

        int totalStops = passengerStops + refuelingStops;

        double travelTimeHours = (double) totalDistance / speed;
        double totalStopTimeHours = totalStops * (stopTimeMinutes / 60.0);
        double totalTimeHours = travelTimeHours + totalStopTimeHours;

        System.out.printf("Total travel time (excluding stops): %.2f hours%n", travelTimeHours);
        System.out.printf("Total stop time: %.2f hours%n", totalStopTimeHours);
        System.out.printf("Total time including stops: %.2f hours%n", totalTimeHours);
    }
}

