/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.returnjourneytimecalculator;

/**
 *
 * @author HP
 */
public class ReturnJourneyTimeCalculator {

    public static void main(String[] args) {
        int totalDistance = 10000;
        int speed = 250;
        int refuelingInterval = 200;
        int stopTimeMinutes = 5;

        int refuelingStops = totalDistance / refuelingInterval;

        if (totalDistance % refuelingInterval == 0) {
            refuelingStops--;
        }

        double travelTimeHours = (double) totalDistance / speed;
        double totalStopTimeHours = refuelingStops * (stopTimeMinutes / 60.0);
        double totalTimeHours = travelTimeHours + totalStopTimeHours;

        System.out.printf("Total travel time (excluding stops): %.2f hours%n", travelTimeHours);
        System.out.printf("Total stop time: %.2f hours%n", totalStopTimeHours);
        System.out.printf("Total time including stops: %.2f hours%n", totalTimeHours);
    }
}

