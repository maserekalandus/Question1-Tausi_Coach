/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.trainstopscalculator;

/**
 *
 * @author HP
 */
public class TrainStopsCalculator {

    public static void main(String[] args) {
        int totalDistance = 10000;
        int passengerStopInterval = 150;
        int refuelingInterval = 200;

        int passengerStops = totalDistance / passengerStopInterval;
        int refuelingStops = totalDistance / refuelingInterval;

        if (totalDistance % passengerStopInterval == 0) {
            passengerStops--;
        }
        if (totalDistance % refuelingInterval == 0) {
            refuelingStops--;
        }

        int totalStops = passengerStops + refuelingStops;

        System.out.printf("Number of passenger stops: %d%n", passengerStops);
        System.out.printf("Number of refueling stops: %d%n", refuelingStops);
        System.out.printf("Total number of stops: %d%n", totalStops);
    }
}

